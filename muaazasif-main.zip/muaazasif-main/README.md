<!-- animation start  -->
  <div align="center">
    <h1> Hi there, I'm Muaaz Asif👋</h1>
  </div>
<p align="center">
<a href="https://github.com/muaazasif"><img src="https://readme-typing-svg.herokuapp.com/?lines=Data+Analysis+and+Python+Developer;+Power+BI+Developer&font=Roboto&size=26&duration=3500&pause=500&center=true&width=500&height=50&color=eab676"></a>

<!-- animation end  -->
			
<img align="right" alt="Coding" width="400" style="border-radius:20px;"
	src="https://raw.githubusercontent.com/devSouvik/devSouvik/master/gif3.gif"/>
<hr>
<h3 style="margin-top: 4px;">BUILDING & ENGAGING THE COMMUNITY</h3>
• 💪🏻 I'm a Web3, and AI Enthusiast.<br>
• 🌱 I’m currently learning LLM's and Generative AI... 😭<br> 
• 🚀 I'm a Consistent, Hard-working, and Motivated person.<br> 
• 📗 I'm currently Learning from Panaverse, PIAIC.<br>
• 🔥 Python Developer and Power BI Developer.<br>
• 💸 LEVEL-01 SELLER of MuaazAsif on Fiverr.<br>
<hr>

<h3 align="center" > <img src="https://media.giphy.com/media/iY8CRBdQXODJSCERIr/giphy.gif" width="30" height="30" style="margin-center: 10px;">Connect with me on 🤝: </h3>

<p align="center">

 <div align="center"  class="icons-social" style="margin-center: 10px;">
<div>   
    <a href="mailto:muhammed.muaaz@gmail.com" target="_blank"><img src="https://img.shields.io/badge/-Email-0D1117?style=for-the-badge&logo=protonmail&logoColor=F0DB4F" alt="MuaazAsif Ali - Email"></a>
    <a href="https://www.linkedin.com/in/muhammed-muaaz/" target="_blank"><img src="https://img.shields.io/badge/Linkedin-0D1117?style=for-the-badge&logo=linkedin&logoColor=F0DB4F" alt="MuaazAsif Ali-Linkedin"></a><br>
    <a href="https://www.facebook.com/muaaz.asif.7/" target="_blank"><img src="https://img.shields.io/badge/Facebook-0D1117?style=for-the-badge&logo=Facebook&logoColor=F0DB4F" alt="MuaazAsif Ali- Facebook"></a>
    <a href="https://www.fiverr.com/muaazasif572" target="_blank"><img src="https://img.shields.io/badge/Fiverr-0D1117?style=for-the-badge&logo=fiverr&logoColor=F0DB4F" alt="Muaaz Asif-fiverr"></a>
<a href="https://community.fabric.microsoft.com/t5/user/viewprofilepage/user-id/329973" target="_blank"><img src="https://img.shields.io/badge/PowerBi-0D1117?style=for-the-badge&logo=PowerBi&logoColor=F0DB4F" alt="MuaazAsif Ali-Power Bi"></a>
	<a href="https://muaazasif.vercel.app/" target="_blank"><img src="https://img.shields.io/badge/Portfolio-0D1117?style=for-the-badge&logo=firefox&logoColor=F0DB4F" alt="MuaazAsif Ali-Portfolio"></a>
	

</div>

</p>

## Top Open Source -
[![CLI ATM Project](https://github-readme-stats.vercel.app/api/pin/?username=muaazasif&repo=cli-atm-project&border_color=7F3FBF&bg_color=0D1117&title_color=C9D1D9&text_color=8B949E&icon_color=7F3FBF)](https://github.com/muaazasif/cli-atm-project)
[![CLI Guessing Number](https://github-readme-stats.vercel.app/api/pin/?username=muaazasif&repo=cli-guessing-number&border_color=7F3FBF&bg_color=0D1117&title_color=C9D1D9&text_color=8B949E&icon_color=7F3FBF)](https://github.com/muaazasif/cli-guessing-number)
[![CLI Simple Calculator](https://github-readme-stats.vercel.app/api/pin/?username=muaazasif&repo=simple-calculator&border_color=7F3FBF&bg_color=0D1117&title_color=C9D1D9&text_color=8B949E&icon_color=7F3FBF)](https://github.com/muaazasif/simple-calculator)
[![MuaazAsif Readme](https://github-readme-stats.vercel.app/api/pin/?username=muaazasif&repo=muaazasif&border_color=7F3FBF&bg_color=0D1117&title_color=C9D1D9&text_color=8B949E&icon_color=7F3FBF)](https://github.com/muaazasif/muaazasif)

<p align="left">
  <a href="https://github.com/muaazasif?tab=repositories" target="_blank"><img alt="All Repositories" title="All Repositories" src="https://img.shields.io/badge/-All%20Repos-2962FF?style=for-the-badge&logo=koding&logoColor=white"/></a>
</p>

<br/>
<hr/>
<br/>

<p align="center">
  <a href="https://github.com/muaazasif">
    <img src="https://github-readme-streak-stats.herokuapp.com/?user=muaazasif&theme=radical&border=7F3FBF&background=0D1117" alt="Saif's GitHub streak"/>
  </a>
</p>

<p align="center">
  <a href="https://github.com/muaazasif">
    <img src="https://github-profile-summary-cards.vercel.app/api/cards/profile-details?username=muaazasif&theme=radical" alt="MuaazAsif's GitHub Contribution"/>
  </a>
</p>

<a> 
    <a href="https://github.com/muaazasif"><img alt="MuaazAsif Github Stats" src="https://denvercoder1-github-readme-stats.vercel.app/api?username=muaazasif&show_icons=true&count_private=true&theme=react&border_color=7F3FBF&bg_color=0D1117&title_color=F85D7F&icon_color=F8D866" height="192px" width="49.5%"/></a>
  <a href="https://github.com/muaazasif"><img alt="MuaazAsif Top Languages" src="https://denvercoder1-github-readme-stats.vercel.app/api/top-langs/?username=muaazasif&langs_count=8&layout=compact&theme=react&border_color=7F3FBF&bg_color=0D1117&title_color=F85D7F&icon_color=F8D866" height="192px" width="49.5%"/></a>
  <br/>
</a>


![MuaazAsif Graph](https://github-readme-activity-graph.vercel.app/graph?username=muaazasif&custom_title=Muaaz%20Asif%20GitHub%20Activity%20Graph&bg_color=0D1117&color=7F3FBF&line=7F3FBF&point=7F3FBF&area_color=FFFFFF&title_color=FFFFFF&area=true)

 
